﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UIManager : MonoBehaviour {

	public GameObject counterText;


	public void UpdateCounter (int counter) {

		counterText.GetComponent<Text> ().text = counter.ToString();

	}

}

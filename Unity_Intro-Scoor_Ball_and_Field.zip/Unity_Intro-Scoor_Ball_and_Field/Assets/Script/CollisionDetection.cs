﻿using UnityEngine;
using System.Collections;

public class CollisionDetection : MonoBehaviour {

	public Texture ballTexture;
	public Texture floorTexture;

	private int count = 0;

	private int counter = 1;

	void OnCollisionEnter(Collision collision) {
		
		if (collision.collider != null) {
			if (count == 0) {
				ChangeTexture (collision.collider.gameObject, ballTexture);
				ChangeTexture (gameObject, floorTexture);
				count = 1;

			} else {
				ChangeTexture (collision.collider.gameObject, floorTexture);
				ChangeTexture (gameObject, ballTexture);
				count = 0;
			
			}
		}


		GameObject.Find("UI").GetComponent<UIManager>().UpdateCounter(counter);
		counter++;

	}


	private void ChangeTexture (GameObject go, Texture texture) {
		go.GetComponent<Renderer> ().material.SetTexture ("_MainTex", texture);

	}


}
